<?php


if (! defined ( 'DIR_CORE' )) {
header ( 'Location: static_pages/' );
}

class ModelShipstationXmlOrders extends Model {

	public $data = array ();
	private $error = array ();

	public function getOrders(){

        header('Content-type: text/xml');
		header('Pragma: public');
		header('Cache-control: private');
		header('Expires: -1');

		$start = (date("N") == 1) ? date("Y-m-d", strtotime("-3 days", strtotime("now"))) : date("Y-m-d", strtotime("-1 days", strtotime("now")));
		$startdate = date("Y-m-d h:i:s", strtotime("-1 day", strtotime($start)));
		$enddate = date("Y-m-d h:i:s", strtotime("+1 day", strtotime("now")));

		$sql = "SELECT *
  		        FROM ".DB_PREFIX."orders WHERE date_added > '".$startdate."' AND date_added < '".$enddate."' ORDER BY order_id DESC ";
        $orders = $this->db->query($sql);
        

        /* create a dom document with encoding utf8 */
	    $domtree = new DOMDocument('1.0', 'UTF-8');

	    /* create the root element of the xml tree */
	    $xmlRoot = $domtree->createElement("Orders");
	    /* append it to the document created */
	    $xmlRoot = $domtree->appendChild($xmlRoot);
	    foreach ($orders->rows as $order) {

	    	$currentOrder = $domtree->createElement("Order");
		    $currentOrder = $xmlRoot->appendChild($currentOrder);

		    /* you should enclose the following two lines in a cicle */
		    $currentOrder->appendChild($domtree->createElement('OrderID','<![CDATA['.$order['order_id'].']]>'));
		    $currentOrder->appendChild($domtree->createElement('OrderNumber','<![CDATA['.$order['order_id'].']]>'));
		    $currentOrder->appendChild($domtree->createElement('OrderDate', date("m/d/Y h:i A", strtotime($order['date_added']))));
		    $currentOrder->appendChild($domtree->createElement('OrderStatus','<![CDATA[paid]]>'));
		    $currentOrder->appendChild($domtree->createElement('LastModified',date("m/d/Y h:i A", strtotime($order['date_modified']))));
		    // $currentOrder->appendChild($domtree->createElement('ShippingMethod','<![CDATA['.$order['shipping_method'].']]>'));
		    // $currentOrder->appendChild($domtree->createElement('PaymentMethod','<![CDATA['.$order['payment_method'].']]>'));
		    $currentOrder->appendChild($domtree->createElement('OrderTotal', round($order['total'], 2)));
		    // $currentOrder->appendChild($domtree->createElement('TaxAmount','0.00'));
		    $currentOrder->appendChild($domtree->createElement('ShippingAmount','0.00'));

		    $currentCustomer = $domtree->createElement("Customer");
		    $currentCustomer = $currentOrder->appendChild($currentCustomer);

		    $currentCustomer->appendChild($domtree->createElement('CustomerCode','<![CDATA['.$order['email'].']]>'));

		    $billing = $domtree->createElement("BillTo");
		    $billing = $currentCustomer->appendChild($billing);

		    $billing->appendChild($domtree->createElement('Name','<![CDATA['.$order['payment_firstname'].' '.$order['payment_lastname'].']]>'));
		    $billing->appendChild($domtree->createElement('Company','<![CDATA['.$order['payment_company'].']]>'));
		    $billing->appendChild($domtree->createElement('Phone','<![CDATA['.$order['telephone'].']]>'));
		    $billing->appendChild($domtree->createElement('Email','<![CDATA['.$order['email'].']]>'));

		    $shipping = $domtree->createElement("ShipTo");
		    $shipping = $currentCustomer->appendChild($shipping);
		    
		    $this->load->model('localisation/country');
		    $country = ($order['shipping_country_id'] != '0') ? $order['shipping_country_id'] : $order['payment_country_id'];
		    $country_info = $this->model_localisation_country->getCountry($country);

		    $shipping->appendChild($domtree->createElement('Name','<![CDATA['.$order['shipping_firstname'].' '.$order['shipping_lastname'].']]>'));
		    $shipping->appendChild($domtree->createElement('Company','<![CDATA['.$order['shipping_company'].']]>'));
		    $shipping->appendChild($domtree->createElement('Phone','<![CDATA['.$order['telephone'].']]>'));
		    $shipping->appendChild($domtree->createElement('Address1','<![CDATA['.$order['shipping_address_1'].']]>'));
		    $shipping->appendChild($domtree->createElement('Address2','<![CDATA['.$order['shipping_address_2'].']]>'));
		    $shipping->appendChild($domtree->createElement('City','<![CDATA['.$order['shipping_city'].']]>'));
		    $shipping->appendChild($domtree->createElement('State','<![CDATA['.$order['shipping_zone'].']]>'));
		    $shipping->appendChild($domtree->createElement('Country',$country_info['iso_code_2']));
		    $shipping->appendChild($domtree->createElement('PostalCode',$order['shipping_postcode']));

			$Items = $domtree->createElement("Items");
		    $Items = $currentOrder->appendChild($Items);

		    $sql = "SELECT *
  		        FROM ".DB_PREFIX."order_products WHERE order_id = '".$order['order_id']."'";
        	$products = $this->db->query($sql);
        	foreach ($products->rows as $product) {
        		
        		$item = $domtree->createElement("Item");
		    	$item = $Items->appendChild($item);

        		$item->appendChild($domtree->createElement('SKU',$product['sku']));
        		$item->appendChild($domtree->createElement('Name','<![CDATA['.$product['name'].']]>'));
        		$item->appendChild($domtree->createElement('Quantity',$product['quantity']));
        		$item->appendChild($domtree->createElement('UnitPrice',round($product['price'], 2)));
        		$item->appendChild($domtree->createElement('Adjustment','true'));
        	}

	    }
	    

	    /* get the xml printed */
	    echo $domtree->saveXML(); die;
	}


	public function updateStatus($data){
		
		$order_id = $data['order_id'];

		$this->db->query("UPDATE `".$this->db->table("orders")."`
							SET order_status_id = '".(int)$data['order_status_id']."',
								date_modified = NOW()
							WHERE order_id = '".(int)$order_id."'");

        if ($data['append']) {
            $this->db->query("INSERT INTO ".$this->db->table("order_history")."
      		                    SET order_id = '".(int)$order_id."',
      		                        order_status_id = '".(int)$data['order_status_id']."',
      		                        notify = '0',
      		                        comment = '".$this->db->escape(strip_tags($data['comment']))."',
      		                        date_added = NOW()");
        }
	}
	
}
