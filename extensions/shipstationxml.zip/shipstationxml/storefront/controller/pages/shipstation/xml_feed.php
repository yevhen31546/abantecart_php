<?php


if (! defined ( 'DIR_CORE' )) {
header ( 'Location: static_pages/' );
}

class ControllerPagesShipstationXmlFeed extends AController {

	public function main(){
		$registry = Registry::getInstance();
        $this->load->model('shipstation/xml_orders');
        $this->model_shipstation_xml_orders->getOrders();
	}

}
