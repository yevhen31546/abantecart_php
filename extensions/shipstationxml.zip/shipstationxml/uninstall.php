<?php


if (! defined ( 'DIR_CORE' )) {
header ( 'Location: static_pages/' );
}




$extension_id = 'shipstationxml';
// delete template layouts
$layout = new ALayoutManager($extension_id);
$layout->deleteTemplateLayouts();