
DROP TABLE IF EXISTS `ac_blog_author`;
DROP TABLE IF EXISTS `ac_blog_author_description`;
DROP TABLE IF EXISTS `ac_blog_category`;
DROP TABLE IF EXISTS `ac_blog_category_description`;
DROP TABLE IF EXISTS `ac_blog_comment`;
DROP TABLE IF EXISTS `ac_blog_entry`;
DROP TABLE IF EXISTS `ac_blog_entry_category_related`;
DROP TABLE IF EXISTS `ac_blog_entry_description`;
DROP TABLE IF EXISTS `ac_blog_entry_product_related`;
DROP TABLE IF EXISTS `ac_blog_entry_to_category`;
DROP TABLE IF EXISTS `ac_blog_notifications`;
DROP TABLE IF EXISTS `ac_blog_related_entry`;
DROP TABLE IF EXISTS `ac_blog_settings`;
DROP TABLE IF EXISTS `ac_blog_user`;
DROP TABLE IF EXISTS `ac_blog_user_role`;
DROP TABLE IF EXISTS `ac_blog_view`;










