//admin
$(function() {
  $('#editSettings_ultra_search_colour_1,#editSettings_ultra_search_colour_2,#editSettings_ultra_search_colour_3,#editSettings_ultra_search_colour_4,#editSettings_ultra_search_colour_5,#editSettings_ultra_search_colour_6,#editSettings_ultra_search_colour_7,#editSettings_ultra_search_colour_8').colorpicker(
    {
      hexNumberSignPrefix: false,
      //customClass: 'colorpicker-2x',
      fallbackColor: null,
    });

});
